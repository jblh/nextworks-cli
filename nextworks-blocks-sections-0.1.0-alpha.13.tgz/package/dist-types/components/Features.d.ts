import React from "react";
import type { Transition } from "motion";
/**
 * Data used to render a FeatureCard within the Features grid.
 * @public
 */
export interface FeatureCardData {
    imageSrc: string;
    imageAlt: string;
    headingText: string;
    subheadingText: string;
}
/**
 * Props for the Features section component.
 *
 * @remarks
 * - Styling: slot-style className overrides are merged after defaults via cn().
 * - Motion: entrance animations respect enableMotion; prefers-reduced-motion
 *   disables transforms and transitions where possible.
 *
 * @public
 */
export interface FeaturesProps {
    /**
     * Optional id to attach to the root section element.
     * @defaultValue "features"
     */
    id?: string;
    /** Main section heading text */
    sectionHeading?: string;
    /** Subheading text displayed below the main heading */
    sectionSubheading?: string;
    /** Array of feature card data objects */
    featuresData?: FeatureCardData[];
    /** Optional top-level class to override the section root */
    className?: string;
    /** Styling configuration objects (slots) */
    section?: {
        className?: string;
    };
    container?: {
        className?: string;
    };
    header?: {
        className?: string;
    };
    heading?: {
        className?: string;
    };
    subheading?: {
        className?: string;
    };
    grid?: {
        className?: string;
    };
    /** Wrapper around each FeatureCard (the animated container) */
    cardWrapper?: {
        className?: string;
    };
    /** Styles passed down to FeatureCard slots */
    card?: {
        className?: string;
    };
    image?: {
        className?: string;
    };
    cardHeading?: {
        className?: string;
    };
    cardSubheading?: {
        className?: string;
    };
    /** When false, disables entrance animations and hover transitions. */
    enableMotion?: boolean;
    /** Motion configuration for the feature items */
    motionConfig?: {
        initial?: {
            opacity?: number;
            y?: number;
        };
        whileInView?: {
            opacity?: number;
            y?: number;
        };
        viewport?: {
            once?: boolean;
            amount?: number;
        };
        transition?: Transition;
    };
    /** ARIA label for the features section */
    ariaLabel?: string;
}
/**
 * Responsive Features section that renders a heading, optional subheading,
 * and a grid of FeatureCard items with configurable entrance animations.
 *
 * @remarks
 * - Styling: slot-style className overrides are merged after defaults via cn().
 * - Motion: Controlled by enableMotion and motionConfig; animations are reduced
 *   or disabled when users prefer reduced motion.
 * - Accessibility: Uses a semantic <section> with an aria-label.
 *
 * @example
 * <Features
 *   sectionHeading="Key Features"
 *   featuresData={[{ imageSrc: "/a.png", imageAlt: "", headingText: "Fast", subheadingText: "Blazing" }]}
 * />
 */
export declare function Features({ id, sectionHeading, sectionSubheading, featuresData, className, section, container, header, heading, subheading, grid, cardWrapper, card, image, cardHeading, cardSubheading, enableMotion, motionConfig, ariaLabel, }: FeaturesProps): React.JSX.Element;
//# sourceMappingURL=Features.d.ts.map