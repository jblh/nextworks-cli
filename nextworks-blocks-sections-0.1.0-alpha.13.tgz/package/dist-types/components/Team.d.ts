import React from "react";
/**
 * A social link shown on a team member card.
 * @public
 */
export interface SocialLink {
    /** Platform name (e.g., "LinkedIn") */
    platform: string;
    /** Destination URL */
    url: string;
    /** Icon identifier or emoji; replace with SVGs in real usage */
    icon: string;
}
/**
 * Team member data rendered by Team.
 * @public
 */
export interface TeamMemberData {
    /** Member name */
    name?: string;
    /** Job role or title */
    role?: string;
    /** Short bio or description */
    bio?: string;
    /** Avatar content (emoji or image URL if swapped out) */
    avatar?: string;
    /** Optional social links */
    socialLinks?: SocialLink[];
}
/**
 * Props for the Team section component.
 *
 * @remarks
 * - Styling: slot-style className overrides are merged after defaults via cn().
 * - Motion: enableMotion controls hover lift on cards.
 * - Accessibility: semantic <section> with aria-label.
 */
export interface TeamProps {
    /** Optional id on root. @defaultValue "team" */
    id?: string;
    /** Top-level className override */
    className?: string;
    /** Section heading text or object. @defaultValue "Meet Our Team" */
    teamHeadingText?: string | {
        text?: string;
        className?: string;
    };
    /** Optional subheading text or object. @defaultValue "The talented people behind your success" */
    teamSubheadingText?: string | {
        text?: string;
        className?: string;
    };
    /** Members to render. @defaultValue DefaultTeamData */
    teamMembers?: TeamMemberData[];
    /** Slot-style overrides */
    section?: {
        className?: string;
    };
    container?: {
        className?: string;
    };
    header?: {
        className?: string;
    };
    heading?: {
        className?: string;
    };
    subheading?: {
        className?: string;
    };
    grid?: {
        className?: string;
    };
    card?: {
        className?: string;
    };
    cardContent?: {
        className?: string;
    };
    avatar?: {
        className?: string;
    };
    name?: {
        className?: string;
    };
    role?: {
        className?: string;
    };
    bio?: {
        className?: string;
    };
    socialLinks?: {
        className?: string;
    };
    socialLink?: {
        className?: string;
    };
    /** When false, removes hover lift on cards */
    enableMotion?: boolean;
    /** ARIA label for the section. @defaultValue "Team section" */
    ariaLabel?: string;
}
/**
 * Team section with heading, subheading, and a responsive member grid.
 *
 * @remarks
 * - Uses a slot-style API for className overrides merged via cn().
 * - Motion: enableMotion toggles hover lift on cards.
 * - Accessibility: semantic <section> with aria-label.
 *
 * @example
 * <Team teamMembers={[{ name: 'Alex', role: 'Engineer' }]} />
 */
export declare function Team({ id, className, teamMembers, teamHeadingText, teamSubheadingText, section, container, header, heading, subheading, grid, card, cardContent, avatar, name, role, bio, socialLinks, socialLink, enableMotion, ariaLabel, }: TeamProps): React.JSX.Element;
//# sourceMappingURL=Team.d.ts.map