import React from "react";
export interface PortfolioProject {
    id: number;
    title: string;
    category: string;
    industry: string;
    result: string;
    description: string;
    image?: string;
    tags: string[];
    color: string;
    url?: string;
}
/**
 * Props for the PortfolioSimple section component.
 *
 * @remarks
 * - Styling: slot-style className overrides are merged after defaults via cn().
 * - Motion: entrance animations respect enableMotion; prefers-reduced-motion is supported.
 *
 * @public
 */
interface PortfolioSimpleProps {
    /** Optional id on root section */
    id?: string;
    /** Root className merged into section slot */
    className?: string;
    projects?: PortfolioProject[];
    /**
     * List of filter labels. Filtering matches project.category exactly.
     * The first item is selected by default; a value of "All Projects" disables filtering.
     */
    filters?: string[];
    /** When false, disables entrance animations and hover transitions. */
    enableMotion?: boolean;
    sectionTitle?: string;
    sectionSubtitle?: string;
    ctaTitle?: string;
    ctaDescription?: string;
    /** Label for the first call-to-action button */
    cta1Label?: string;
    /** URL or anchor target for the first CTA button */
    cta1Href?: string;
    /** Label for the second call-to-action button */
    cta2Label?: string;
    /** URL or anchor target for the second CTA button */
    cta2Href?: string;
    /** Styling configuration objects */
    section?: {
        className?: string;
    };
    container?: {
        className?: string;
    };
    header?: {
        className?: string;
    };
    title?: {
        className?: string;
    };
    subtitle?: {
        className?: string;
    };
    filterContainer?: {
        className?: string;
    };
    filterButton?: {
        className?: string;
    };
    activeFilterButton?: {
        className?: string;
    };
    grid?: {
        className?: string;
    };
    projectCard?: {
        className?: string;
    };
    imageContainer?: {
        className?: string;
    };
    projectInfo?: {
        className?: string;
    };
    projectTitle?: {
        className?: string;
    };
    projectDescription?: {
        className?: string;
    };
    tagsContainer?: {
        className?: string;
    };
    tagStyle?: {
        className?: string;
    };
    result?: {
        className?: string;
    };
    ctaSection?: {
        className?: string;
    };
    ctaTitleStyle?: {
        className?: string;
    };
    ctaDescriptionStyle?: {
        className?: string;
    };
    ctaButtons?: {
        className?: string;
    };
    cta1Button?: {
        className?: string;
    };
    cta2Button?: {
        className?: string;
    };
    /** Called when a project image or card is clicked. */
    onProjectClick?: (project: PortfolioProject) => void;
    onPrimaryCtaClick?: () => void;
    onSecondaryCtaClick?: () => void;
    /** ARIA label for the portfolio section */
    ariaLabel?: string;
}
/**
 * Responsive portfolio/gallery grid with simple category filtering and CTA block.
 *
 * @remarks
 * - Filtering uses exact category match; include "All Projects" to disable filtering.
 * - Accessibility: Renders a semantic <section> with aria-label; ensure images have informative titles or alt text.
 *
 * @example
 * <PortfolioSimple sectionTitle="Our Work" />
 */
export declare function PortfolioSimple({ id, className, projects, filters, enableMotion, sectionTitle, sectionSubtitle, ctaTitle, ctaDescription, cta1Label, cta1Href, cta2Label, cta2Href, section, container, header, title, subtitle, filterContainer, filterButton, activeFilterButton, grid, projectCard, imageContainer, projectInfo, projectTitle, projectDescription, tagsContainer, tagStyle, result, ctaSection, ctaTitleStyle, ctaDescriptionStyle, ctaButtons, cta1Button, cta2Button, onProjectClick, onPrimaryCtaClick, onSecondaryCtaClick, ariaLabel, }: PortfolioSimpleProps): React.JSX.Element;
export {};
//# sourceMappingURL=PortfolioSimple.d.ts.map