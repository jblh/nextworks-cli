import React from "react";
type FieldType = "text" | "email" | "tel" | "textarea";
/**
 * Configuration for a single form field in the Contact section.
 * @public
 */
export interface ContactField {
    /** Unique id/name for the field. Used for htmlFor and form submission. */
    id: string;
    /** Visible label text for the field */
    label: string;
    /** Placeholder text rendered inside the input */
    placeholder?: string;
    /** Whether the field is required for form submission */
    required?: boolean;
    /** Type of field to render (text, email, tel, textarea). */
    type?: FieldType;
}
/**
 * Props for the Contact section component.
 *
 * @remarks
 * - Styling: exposes slot-style className overrides (section, container,
 *   headerWrapper, headerText, subheaderText, form, fieldsWrapper, field,
 *   label, input, textarea, submitButtonWrapper, submitButtonStyle). Consumer
 *   classes are merged after defaults via cn().
 * - Behavior: onSubmit is called with the form event after default
 *   prevention. Provide your own handler to integrate with APIs.
 * - Motion: controlled by enableMotion; when false, removes button hover lift.
 * - Accessibility: rendered as a semantic <section> with aria-label.
 */
export interface ContactProps {
    /** Array of fields to render in the form. @defaultValue defaultFormData */
    fields?: ContactField[];
    /** Heading text above the form. @defaultValue "Ready to Grow Your Business?" */
    contactHeaderText?: string;
    /** Subheading under the header. @defaultValue "Schedule a free consultation with our experts." */
    contactSubHeaderText?: string;
    /** Optional id to attach to the root section element. @defaultValue "contact" */
    id?: string;
    /** Optional top-level class to override the section root */
    className?: string;
    /** Styling configuration objects (slots) */
    section?: {
        className?: string;
    };
    container?: {
        className?: string;
    };
    headerWrapper?: {
        className?: string;
    };
    headerText?: {
        className?: string;
    };
    subheaderText?: {
        className?: string;
    };
    form?: {
        className?: string;
    };
    fieldsWrapper?: {
        className?: string;
    };
    field?: {
        className?: string;
    };
    label?: {
        className?: string;
    };
    input?: {
        className?: string;
    };
    textarea?: {
        className?: string;
    };
    submitButtonWrapper?: {
        className?: string;
    };
    submitButtonStyle?: {
        unstyled?: boolean;
        style?: React.CSSProperties;
        variant?: "default" | "destructive" | "outline" | "secondary" | "ghost" | "link";
        size?: "default" | "sm" | "lg" | "icon";
        className?: string;
    };
    /** Text for the submit button. @defaultValue "Schedule Free Consultation" */
    submitButtonText?: string;
    /** Callback fired on submit; default prevented. */
    onSubmit?: (e: React.FormEvent<HTMLFormElement>) => void;
    /** ARIA label for the section. @defaultValue "Contact section" */
    ariaLabel?: string;
    /** When false, removes hover lift/transition on the submit button */
    enableMotion?: boolean;
}
/**
 * Contact section with a configurable form and submit action.
 *
 * @remarks
 * - Styling: slot-style className overrides are merged via cn().
 * - Behavior: onSubmit is invoked with the form event after calling
 *   preventDefault().
 * - Motion: enableMotion toggles the button hover lift/transition.
 * - Accessibility: Uses a semantic <section> with aria-label.
 *
 * @example
 * <Contact onSubmit={(e) => { // send to your API }} />
 */
export declare function Contact({ fields, contactHeaderText, contactSubHeaderText, id, className, section, container, headerWrapper, headerText, subheaderText, form, fieldsWrapper, field, label, input, textarea, submitButtonWrapper, submitButtonStyle, submitButtonText, onSubmit, ariaLabel, enableMotion, }: ContactProps): React.JSX.Element;
export {};
//# sourceMappingURL=Contact.d.ts.map