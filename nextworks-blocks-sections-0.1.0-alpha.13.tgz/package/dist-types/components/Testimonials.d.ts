import React from "react";
/**
 * Data used to render a TestimonialCard.
 * @public
 */
export interface TestimonialCardData {
    /** The testimonial quote text */
    testimonialText: string;
    /** The author's display name (prefixed with hyphen in defaults) */
    testimonialAuthor: string;
    /** Author initials displayed in the avatar */
    testimonialAuthorInitials: string;
}
/**
 * Props for the Testimonials section component.
 *
 * @remarks
 * - Styling: slot-style className overrides are merged after defaults via cn().
 * - Motion: enableMotion toggles card hover transitions.
 * - Accessibility: semantic <section> with aria-label.
 */
export interface TestimonialsProps {
    /** Optional id */
    id?: string;
    /** Root className merged into slots */
    className?: string;
    /** Testimonial items to render. @defaultValue defaultTestimonialData */
    testimonials?: TestimonialCardData[];
    /** Heading displayed above the grid. @defaultValue "What Our Customers Say" */
    testimonialSectionHeader?: string;
    /** When false, disables hover transitions on cards */
    enableMotion?: boolean;
    /** Slot-style overrides */
    section?: {
        className?: string;
    };
    container?: {
        className?: string;
    };
    header?: {
        className?: string;
    };
    heading?: {
        className?: string;
    };
    grid?: {
        className?: string;
    };
    card?: {
        className?: string;
    };
    content?: {
        className?: string;
    };
    text?: {
        className?: string;
    };
    author?: {
        className?: string;
    };
    avatar?: {
        className?: string;
    };
    avatarText?: {
        className?: string;
    };
    /** ARIA label for the section. @defaultValue "Testimonials section" */
    ariaLabel?: string;
}
/**
 * Testimonials section that renders a grid of TestimonialCard items.
 *
 * @remarks
 * - Slot-style overrides match TestimonialCard sub-slots (card, content, text, etc.).
 * - Motion can be disabled via enableMotion.
 *
 * @example
 * <Testimonials testimonials={[{ testimonialText: 'Great!', testimonialAuthor: ' - Jane', testimonialAuthorInitials: 'J' }]} />
 */
export declare function Testimonials({ id, className, testimonials, testimonialSectionHeader, enableMotion, section, container, header, heading, grid, card, content, text, author, avatar, avatarText, ariaLabel, }: TestimonialsProps): React.JSX.Element;
//# sourceMappingURL=Testimonials.d.ts.map