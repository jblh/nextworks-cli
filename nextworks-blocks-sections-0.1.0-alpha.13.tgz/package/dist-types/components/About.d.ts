import React from "react";
/**
 * Data used to render a single statistic in the About section.
 *
 * @remarks
 * Typical examples include counts like projects completed or years of
 * experience. The suffix lets you append symbols such as "+", "%", or "/7".
 *
 * @public
 */
export interface AboutStatData {
    /** The main numeric/text value (e.g., "50") */
    value?: string;
    /** Short label describing the stat (e.g., "Successful Projects") */
    label?: string;
    /** Optional suffix appended to the value (e.g., "+") */
    suffix?: string;
}
/**
 * Props for the About section component.
 *
 * @remarks
 * - Styling: exposes slot-style className overrides (section, container,
 *   inner, contentContainer, contentStack, subheading, heading, content,
 *   statsSection, statsGrid, statItem, statNumber, statLabel). Consumer
 *   classes are merged after defaults via cn().
 * - Layout: text alignment can be set via aboutTextAlign.
 * - Motion: animateStats enables a count-up animation for numeric stats on first viewport visibility.
 * - Accessibility: rendered as a semantic <section> with aria-label.
 */
interface AboutProps {
    /** Main heading text displayed in the section header. @defaultValue "Your Success Is Our Mission" */
    aboutHeadingText?: string;
    /** Optional subheading text displayed above the heading. */
    aboutSubheadingText?: string;
    /** Primary paragraph/content body. @defaultValue a short marketing blurb */
    aboutContentText?: string;
    /** Optional list of statistics to render below the content. @defaultValue defaultStatsData */
    aboutStats?: AboutStatData[];
    /** Optional top-level class to override the section root */
    className?: string;
    /** Slot-style overrides */
    section?: {
        className?: string;
    };
    container?: {
        className?: string;
    };
    inner?: {
        className?: string;
    };
    contentContainer?: {
        className?: string;
    };
    contentStack?: {
        className?: string;
    };
    subheading?: {
        className?: string;
    };
    heading?: {
        className?: string;
    };
    content?: {
        className?: string;
    };
    statsSection?: {
        className?: string;
    };
    statsGrid?: {
        className?: string;
    };
    statItem?: {
        className?: string;
    };
    statNumber?: {
        className?: string;
    };
    statLabel?: {
        className?: string;
    };
    /** Controls text alignment at various breakpoints. @defaultValue "center" */
    aboutTextAlign?: "left" | "center" | "right";
    /** Whether to render the stats block at the bottom. @defaultValue true */
    showStats?: boolean;
    /** Enable count-up animation for numeric stats when they enter the viewport. @defaultValue false */
    animateStats?: boolean;
    /** ARIA label for the section. @defaultValue "About section" */
    ariaLabel?: string;
}
export declare function About({ aboutHeadingText, aboutSubheadingText, aboutContentText, aboutStats, className, section, container, inner, contentContainer, contentStack, subheading, heading, content, statsSection, statsGrid, statItem, statNumber, statLabel, aboutTextAlign, showStats, animateStats, ariaLabel, }: AboutProps): React.JSX.Element;
export {};
//# sourceMappingURL=About.d.ts.map