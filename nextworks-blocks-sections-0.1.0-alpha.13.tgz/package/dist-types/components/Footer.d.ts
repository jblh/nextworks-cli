import React from "react";
/**
 * Navigation link item interface representing a single link in the footer.
 */
export interface NavLinkItem {
    /** Display name of the link */
    name: string;
    /** URL or anchor for the navigation link */
    href: string;
    /** Whether the link should open in a new tab */
    external?: boolean;
}
/**
 * Grouping for navigation link items under a section heading.
 */
export interface NavLinkGroup {
    /** Section heading/title */
    heading: string;
    /** Collection of links under this section */
    links: NavLinkItem[];
}
/**
 * Social media link interface for footer social icons.
 * @public
 */
export interface SocialLink {
    /** Name of the social media platform */
    name: string;
    /** SVG icon component (e.g., Lucide). Should respect currentColor. */
    icon: React.ComponentType<React.SVGProps<SVGSVGElement>>;
    /** URL to the social profile */
    url: string;
    /** Optional aria-label for accessibility */
    label?: string;
    /** Whether the link should open in a new tab */
    external?: boolean;
}
/**
 * Props for the Footer component.
 *
 * @remarks
 * Exposes slot-style className overrides for layout and typography. External
 * links automatically receive target and rel attributes for security.
 *
 * @public
 */
export interface FooterProps {
    /** Optional id to attach to the root footer element */
    id?: string;
    /** Brand name or logo text displayed in the footer */
    footerBrandName?: string;
    /** Optional custom brand node (e.g., logo). Rendered left of brand text */
    brandNode?: React.ReactNode;
    /** Optional link for the brand (wraps brand text) */
    brandHref?: string;
    /** Navigation link groups shown in the footer */
    footerNavLinks?: NavLinkGroup[];
    /** Social media links and icons shown in the footer */
    footerSocialLinks?: SocialLink[];
    /** Optional top-level class to override the footer root */
    className?: string;
    /** Styling configuration objects (slot-based API) */
    section?: {
        className?: string;
    };
    container?: {
        className?: string;
    };
    brand?: {
        className?: string;
    };
    brandWrapper?: {
        className?: string;
    };
    navSection?: {
        className?: string;
    };
    navGroup?: {
        className?: string;
    };
    navHeading?: {
        className?: string;
    };
    navLink?: {
        className?: string;
    };
    linksList?: {
        className?: string;
    };
    socialSection?: {
        className?: string;
    };
    socialLink?: {
        className?: string;
    };
    socialIcon?: {
        className?: string;
    };
    copyright?: {
        className?: string;
    };
    /** Optional overrides for copyright */
    copyrightYear?: number;
    copyrightOverride?: React.ReactNode;
    /** ARIA label for the footer section */
    ariaLabel?: string;
}
/**
 * Site footer with brand, grouped navigation links, social icons, and copyright.
 *
 * @remarks
 * - Styling: slot-style className overrides are merged after defaults via cn().
 * - Accessibility: renders a semantic <footer> with aria-label and clear link
 *   names; external links open in a new tab with rel security attributes.
 *
 * @example
 * <Footer footerBrandName="Acme" />
 */
export declare function Footer({ id, footerBrandName, brandNode, brandHref, footerNavLinks, footerSocialLinks, className, section, container, brand, brandWrapper, navSection, navGroup, navHeading, navLink, linksList, socialSection, socialLink, socialIcon, copyright, copyrightYear, copyrightOverride, ariaLabel, }: FooterProps): React.JSX.Element;
//# sourceMappingURL=Footer.d.ts.map