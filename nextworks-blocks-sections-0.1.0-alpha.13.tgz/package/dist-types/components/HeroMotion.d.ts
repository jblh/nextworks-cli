import React from "react";
import type { Transition } from "motion";
/**
 * Props for the HeroMotion component.
 *
 * @remarks
 * - Styling: exposes slot-style className overrides merged via cn().
 * - Motion: controlled by enableMotion and motionOptions; respects
 *   prefers-reduced-motion by allowing disabling transforms.
 * - Accessibility: rendered as a semantic <section> with aria-label.
 * - CTA: primary/secondary CTA can be links (href provided) or buttons.
 */
export interface HeroMotionProps {
    /** Optional id to attach to the section root */
    id?: string;
    /** ARIA label for the section. @defaultValue "Hero section" */
    ariaLabel?: string;
    /** Optional top-level class to override the root */
    className?: string;
    /** Primary heading text. Ignored when headingNode is provided. */
    heading?: string;
    /** Custom heading node; use for advanced layouts or styling. */
    headingNode?: React.ReactNode;
    /** Inline highlight node rendered next to heading text. */
    highlight?: React.ReactNode;
    /** Optional description paragraph/node */
    description?: React.ReactNode;
    /** Primary call to action config or null to hide */
    primaryCta?: {
        label: string;
        href?: string;
    } | null;
    /** Secondary call to action config or null to hide */
    secondaryCta?: {
        label: string;
        href?: string;
    } | null;
    /** Slot-style overrides */
    section?: {
        className?: string;
    };
    container?: {
        className?: string;
    };
    content?: {
        className?: string;
    };
    headingText?: {
        className?: string;
    };
    highlightText?: {
        className?: string;
    };
    descriptionText?: {
        className?: string;
    };
    actions?: {
        className?: string;
    };
    primaryButtonStyle?: {
        unstyled?: boolean;
        style?: React.CSSProperties;
        variant?: "default" | "destructive" | "outline" | "secondary" | "ghost" | "link";
        size?: "default" | "sm" | "lg" | "icon";
        className?: string;
    };
    secondaryButtonStyle?: {
        unstyled?: boolean;
        style?: React.CSSProperties;
        variant?: "default" | "destructive" | "outline" | "secondary" | "ghost" | "link";
        size?: "default" | "sm" | "lg" | "icon";
        className?: string;
    };
    /** Optional background node (e.g., SVGs, gradients, images) */
    backgroundNode?: React.ReactNode;
    /** When false, disables entrance animations */
    enableMotion?: boolean;
    /** Motion configuration for entrance sequences */
    motionOptions?: {
        viewport?: {
            once?: boolean;
            amount?: number;
        };
        headingDelay?: number;
        descriptionDelay?: number;
        actionsDelay?: number;
        transition: Transition;
    };
}
/**
 * Motion-first hero with heading/highlight, optional description and CTAs.
 *
 * @remarks
 * - Styling: slot-style className overrides are merged after defaults via cn().
 * - Motion: enableMotion toggles entrance transitions; motionOptions controls
 *   delays and viewport.
 * - Accessibility: semantic <section> with aria-label.
 *
 * @example
 * <HeroMotion
 *   heading="Supercharge growth with"
 *   highlight="AI-powered insights"
 *   primaryCta={{ label: 'Get Started', href: '#contact' }}
 * />
 */
export declare function HeroMotion({ id, ariaLabel, className, heading, headingNode, highlight, description, primaryCta, secondaryCta, section, container, content, headingText, highlightText, descriptionText, actions, primaryButtonStyle, secondaryButtonStyle, enableMotion, motionOptions, backgroundNode, }: HeroMotionProps): React.JSX.Element;
//# sourceMappingURL=HeroMotion.d.ts.map