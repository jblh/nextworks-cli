import React from "react";
/**
 * A single trust badge (stat or certification).
 * @public
 */
export interface TrustBadgeData {
    /** Main badge text (e.g., "99.9% Uptime") */
    badgeText: string;
    /** Optional short descriptor above/below the text */
    badgeDescription?: string;
    /** Optional icon/emoji representation */
    badgeIcon?: string;
}
/**
 * Props for the TrustBadges section component.
 *
 * @remarks
 * - Layout: choose horizontal row or vertical stack via layout.
 * - Styling: slot-style overrides are merged after defaults via cn().
 * - Motion: enableMotion toggles hover scale.
 */
export interface TrustBadgesProps {
    /** Optional id on root. @defaultValue "trust-badges" */
    id?: string;
    /** Root className merged into section slot */
    className?: string;
    /** Badges to display. @defaultValue defaultTrustBadgeData */
    badges?: TrustBadgeData[];
    /** Optional heading above badges */
    trustBadgesSectionHeader?: string;
    /** Slot-style overrides */
    section?: {
        className?: string;
    };
    container?: {
        className?: string;
    };
    header?: {
        className?: string;
    };
    heading?: {
        className?: string;
    };
    badgesContainer?: {
        className?: string;
    };
    badge?: {
        className?: string;
    };
    badgeContent?: {
        className?: string;
    };
    icon?: {
        className?: string;
    };
    description?: {
        className?: string;
    };
    text?: {
        className?: string;
    };
    /** Layout orientation. @defaultValue "horizontal" */
    layout?: "horizontal" | "vertical";
    /** When false, disables hover scale */
    enableMotion?: boolean;
    /** ARIA label for the section. @defaultValue "Trust badges section" */
    ariaLabel?: string;
}
/**
 * Compact section to showcase trust signals like usage stats and compliance.
 *
 * @remarks
 * - Horizontal by default; switch to vertical with layout="vertical".
 * - Hover motion can be disabled via enableMotion.
 *
 * @example
 * <TrustBadges badges={[{ badgeText: 'SOC 2', badgeDescription: 'Security', badgeIcon: '🔒' }]} />
 */
export declare function TrustBadges({ id, className, badges, trustBadgesSectionHeader, section, container, header, heading, badgesContainer, badge, badgeContent, icon, description, text, layout, enableMotion, ariaLabel, }: TrustBadgesProps): React.JSX.Element;
//# sourceMappingURL=TrustBadges.d.ts.map