import React from "react";
/**
 * Props for the HeroSplit component.
 *
 * @remarks
 * - Layout: split hero with text and image. imageLayout controls whether the
 *   image is full-bleed or padded.
 * - Styling: slot-style className overrides are merged via cn(). Heading and
 *   subheading accept either a string or a { text, className } object.
 * - Motion: enableMotion toggles button hover lift transitions.
 * - Accessibility: uses a semantic <section> with aria-label.
 */
interface HeroSplitProps {
    /** Optional id to attach to the root section element */
    id?: string;
    /** Optional top-level class to override the root */
    className?: string;
    /** Section slot override */
    section?: {
        className?: string;
    };
    /** Heading string or object with text and className */
    heading?: string | {
        text?: string;
        className?: string;
    };
    /** Subheading string or object with text and className */
    subheading?: string | {
        text?: string;
        className?: string;
    };
    /** Primary CTA configuration */
    cta1?: {
        label?: string;
        href?: string;
        variant?: "default" | "destructive" | "outline" | "secondary" | "ghost" | "link";
        size?: "default" | "sm" | "lg" | "icon";
        className?: string;
        /** When true, renders the Button in unstyled mode to avoid token bleed from variants */
        unstyled?: boolean;
        /** Optional inline style forwarded to Button */
        style?: React.CSSProperties;
    };
    /** Secondary CTA configuration */
    cta2?: {
        label?: string;
        href?: string;
        variant?: "default" | "destructive" | "outline" | "secondary" | "ghost" | "link";
        size?: "default" | "sm" | "lg" | "icon";
        className?: string;
        /** When true, renders the Button in unstyled mode to avoid token bleed from variants */
        unstyled?: boolean;
        /** Optional inline style forwarded to Button */
        style?: React.CSSProperties;
    };
    /** Image configuration */
    image?: {
        src?: string;
        alt?: string;
        className?: string;
    };
    /** Image container slot */
    imageContainer?: {
        className?: string;
    };
    /** Text container slot */
    textContainer?: {
        className?: string;
    };
    /** Buttons container slot */
    buttonsContainer?: {
        className?: string;
    };
    /** Text alignment at large breakpoints. @defaultValue "center" */
    textAlign?: "left" | "center" | "right";
    /** Fallback node shown when no image.src is provided */
    fallback?: React.ReactNode;
    /** ARIA label for the section. @defaultValue "Hero section" */
    ariaLabel?: string;
    /** When false, removes button hover lifts, keeps layout static */
    enableMotion?: boolean;
    /** "padded" keeps default gutters. "full-bleed" allows the image to touch page edges. @defaultValue "full-bleed" */
    imageLayout?: "padded" | "full-bleed";
}
/**
 * Split hero with text on one side and an image on the other.
 *
 * @remarks
 * - Text props accept string or object forms to easily override classes.
 * - Full-bleed layout absolutely positions the image on larger screens.
 * - Motion only affects the subtle hover lift on CTA buttons.
 *
 * @example
 * <HeroSplit heading="Build faster" subheading="Launch confidently" />
 */
export declare function HeroSplit({ id, className, heading, subheading, section, cta1, cta2, image, imageContainer, textContainer, buttonsContainer, textAlign, fallback, ariaLabel, enableMotion, imageLayout, }: HeroSplitProps): React.JSX.Element;
export {};
//# sourceMappingURL=HeroSplit.d.ts.map