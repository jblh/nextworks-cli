import React from "react";
/**
 * Props for a compact newsletter/signup block.
 *
 * - Slot-style API (section, container, header, heading, subheading, form, formRow, input, button)
 * - Merges consumer classes with sensible defaults via cn(...)
 * - Uses CSS vars in defaults so token/theming overrides don't break
 */
export interface NewsletterProps {
    id?: string;
    className?: string;
    headingText?: string;
    subheadingText?: string;
    /** Called after successful submit (form event will be passed) */
    onSubmit?: (e: React.FormEvent<HTMLFormElement>, email: string) => void;
    /** Slot-style overrides */
    section?: {
        className?: string;
    };
    container?: {
        className?: string;
    };
    header?: {
        className?: string;
    };
    heading?: {
        className?: string;
    };
    subheading?: {
        className?: string;
    };
    form?: {
        className?: string;
    };
    formRow?: {
        className?: string;
    };
    input?: {
        className?: string;
    };
    button?: {
        className?: string;
        variant?: any;
        size?: any;
        unstyled?: boolean;
    };
    enableMotion?: boolean;
    ariaLabel?: string;
}
/**
 * Compact newsletter/signup block.
 *
 * Usage:
 * <Newsletter section={{ className: "bg-gradient-to-r ..." }} />
 *
 * Slots exposed: section, container, header, heading, subheading, form, formRow, input, button
 */
export declare function Newsletter({ id, className, headingText, subheadingText, onSubmit, section, container, header, heading, subheading, form, formRow, input, button, enableMotion, ariaLabel, }: NewsletterProps): React.JSX.Element;
//# sourceMappingURL=Newsletter.d.ts.map