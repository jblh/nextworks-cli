import React from "react";
import { type ThemeToggleProps } from "@nextworks/blocks-core";
/**
 * Props for the Navbar component.
 *
 * @remarks
 * Slot-style className overrides are available for structural parts. The mobile
 * menu locks body scroll when open and restores it on close/unmount.
 *
 * @public
 */
export interface NavbarProps {
    /** Optional id to attach to the root nav element */
    id?: string;
    /** The height of the navbar as a Tailwind class. Example: "h-16" or "h-[13vh]" */
    navHeight?: string;
    /**
     * The text displayed as the brand/logo.
     * @defaultValue "Brand Name"
     */
    brand?: string;
    /** Optional custom brand node (e.g., logo). Rendered left of brand text */
    brandNode?: React.ReactNode;
    /** Navigation links array. Each item has a label and href */
    menuItems?: {
        label: string;
        href: string;
    }[];
    /**
     * Call to action button config or null to hide it.
     * Example: { label: "Get Started", href: "#contact" }
     */
    ctaButton?: {
        label: string;
        href: string;
    } | null;
    /**
     * Whether to display the color mode toggle.
     * @defaultValue true
     */
    showColorModeToggle?: boolean;
    /**
     * Whether navbar should stick to top when scrolling.
     * @defaultValue true
     */
    sticky?: boolean;
    /** Optional top-level class to override the nav root */
    className?: string;
    /** Styling configuration objects */
    nav?: {
        className?: string;
    };
    brandText?: {
        className?: string;
    };
    links?: {
        className?: string;
    };
    ctaButtonStyle?: {
        unstyled?: boolean;
        style?: React.CSSProperties;
        variant?: "default" | "destructive" | "outline" | "secondary" | "ghost" | "link";
        size?: "default" | "sm" | "lg" | "icon";
        className?: string;
    };
    mobileMenu?: {
        className?: string;
    };
    container?: {
        className?: string;
    };
    brandWrapper?: {
        className?: string;
    };
    desktopMenu?: {
        className?: string;
    };
    toggleButton?: {
        className?: string;
    };
    colorModeWrapper?: {
        className?: string;
    };
    ctaButtonWrapper?: {
        className?: string;
    };
    mobileMenuInner?: {
        className?: string;
    };
    /** Additional class overrides for mobile menu link hover/background, etc. */
    mobileLinks?: {
        className?: string;
    };
    /** Props forwarded to ThemeToggle so templates can fully style it */
    themeToggle?: ThemeToggleProps;
    /** ARIA label for the navbar. */
    ariaLabel?: string;
}
/**
 * Responsive navbar with brand, menu links, color mode toggle, and optional CTA.
 *
 * @remarks
 * - Sticky behavior is enabled by default (sticky top-0 z-50).
 * - Mobile menu toggles with a button and traps body scroll while open.
 * - Accessibility: Focus rings are applied to interactive elements; aria
 *   attributes are set on the toggle button for state.
 *
 * @example
 * <Navbar brand="Acme" />
 */
export declare function Navbar({ id, navHeight, brand, brandNode, menuItems, ctaButton, showColorModeToggle, sticky, className, nav, brandText, links, ctaButtonStyle, mobileMenu, container, brandWrapper, desktopMenu, toggleButton, colorModeWrapper, ctaButtonWrapper, mobileMenuInner, mobileLinks, themeToggle, ariaLabel, }: NavbarProps): React.JSX.Element;
//# sourceMappingURL=Navbar.d.ts.map