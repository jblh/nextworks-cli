import React from "react";
/**
 * Represents a single FAQ item.
 * @public
 */
export interface FAQS {
    /** The question text */
    question?: string;
    /** The answer text */
    answer?: string;
}
/**
 * Props for the FAQ section component.
 *
 * @remarks
 * - Styling: exposes slot-style className overrides; consumer classes are
 *   merged after defaults via cn().
 * - Behavior: supports single or multiple open items; default open indices
 *   are respected. Controlled internally with a Set.
 * - Motion: when enableMotion is false, collapse/expand transitions are
 *   removed for a hard-cut.
 * - Accessibility: each item uses button+region with aria-controls and
 *   aria-expanded. Section uses aria-label.
 */
export interface FAQProps {
    /** Header text displayed at the top of the FAQ section. @defaultValue "Frequently Asked Questions" */
    faqSectionHeaderText?: string;
    /** Array of question/answer items. @defaultValue defaultFaqData */
    faqData?: FAQS[];
    /** Optional id for the section root. @defaultValue "faq" */
    sectionId?: string;
    /** Optional top-level class override */
    className?: string;
    /** When false, only one item can be open at a time. @defaultValue true */
    allowMultipleOpen?: boolean;
    /** Indices of items that should be open by default. @defaultValue [] */
    defaultOpenIndices?: number[];
    /** Optional icons for open/closed states */
    openIcon?: React.ReactNode;
    closedIcon?: React.ReactNode;
    /** ARIA label for the FAQ section. @defaultValue "Frequently asked questions section" */
    ariaLabel?: string;
    /** Slot-style overrides */
    section?: {
        className?: string;
    };
    container?: {
        className?: string;
    };
    heading?: {
        className?: string;
    };
    grid?: {
        className?: string;
    };
    item?: {
        className?: string;
    };
    questionButton?: {
        className?: string;
    };
    questionText?: {
        className?: string;
    };
    chevronIcon?: {
        className?: string;
    };
    answer?: {
        className?: string;
    };
    answerText?: {
        className?: string;
    };
    /** When false, removes transition on collapse/expand for a hard-cut */
    enableMotion?: boolean;
}
/**
 * Expandable FAQ section with accessible toggles and optional icons.
 *
 * @remarks
 * - Supports multiple or single open item behavior via allowMultipleOpen.
 * - Uses button with aria-expanded and a region with aria-labelledby.
 * - Motion can be disabled via enableMotion for reduced animation.
 *
 * @example
 * <FAQ faqData={[{ question: 'What is X?', answer: 'Y' }]} />
 */
export declare function FAQ({ faqSectionHeaderText, faqData, sectionId, className, allowMultipleOpen, defaultOpenIndices, openIcon, closedIcon, ariaLabel, section, container, heading, grid, item, questionButton, questionText, chevronIcon, answer, answerText, enableMotion, }: FAQProps): React.JSX.Element;
//# sourceMappingURL=FAQ.d.ts.map