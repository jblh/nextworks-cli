import React from "react";
/**
 * Props for the HeroOverlay component.
 *
 * @remarks
 * - Prefer the structured image prop (image) over deprecated flat props.
 * - Slot-style className overrides are merged after defaults via cn().
 * - Motion controls affect CTA hover transitions.
 *
 * @public
 */
export interface HeroOverlayProps {
    id?: string;
    className?: string;
    image?: {
        src?: string;
        alt?: string;
        className?: string;
        objectFit?: React.CSSProperties["objectFit"];
        objectPosition?: React.CSSProperties["objectPosition"];
    };
    /** @deprecated Use image.src instead */
    imageSrc?: string;
    /** @deprecated Use image.alt instead */
    imageAlt?: string;
    /** @deprecated Use image.objectFit instead */
    imageObjectFit?: React.CSSProperties["objectFit"];
    /** @deprecated Use image.objectPosition instead */
    imageObjectPosition?: React.CSSProperties["objectPosition"];
    heading?: string | {
        text?: string;
        className?: string;
    };
    subheading?: string | {
        text?: string;
        className?: string;
    };
    overlayRGBA?: string;
    overlayDarkRGBA?: string;
    section?: {
        className?: string;
    };
    container?: {
        className?: string;
    };
    imageContainer?: {
        className?: string;
    };
    overlay?: {
        className?: string;
    };
    content?: {
        className?: string;
    };
    textContainer?: {
        className?: string;
    };
    /** @deprecated Use heading.className */
    headingStyle?: {
        className?: string;
    };
    /** @deprecated Use subheading.className */
    subheadingStyle?: {
        className?: string;
    };
    ctaContainer?: {
        className?: string;
    };
    cta1?: {
        label?: string;
        href?: string;
        variant?: "default" | "destructive" | "outline" | "secondary" | "ghost" | "link";
        size?: "default" | "sm" | "lg" | "icon";
        className?: string;
        unstyled?: boolean;
        style?: React.CSSProperties;
    };
    cta2?: {
        label?: string;
        href?: string;
        variant?: "default" | "destructive" | "outline" | "secondary" | "ghost" | "link";
        size?: "default" | "sm" | "lg" | "icon";
        className?: string;
        unstyled?: boolean;
        style?: React.CSSProperties;
    };
    /** @deprecated Use cta1.label instead */
    ctaBtn1Label?: string;
    /** @deprecated Use cta1.href instead */
    ctaBtn1Href?: string;
    /** @deprecated Use cta2.label instead */
    ctaBtn2Label?: string;
    /** @deprecated Use cta2.href instead */
    ctaBtn2Href?: string;
    ariaLabel?: string;
    enableMotion?: boolean;
}
/**
 * Full-bleed image hero with color overlay, heading/subheading, and up to two CTAs.
 *
 * @remarks
 * - Styling: slot-style overrides for container, imageContainer, overlay, content, textContainer.
 * - Motion: enableMotion applies hover-lift transitions to CTA buttons only.
 * - Accessibility: uses semantic <section> with aria-label; background image is
 *   decorative with overlay and text content provided separately.
 *
 * @example
 * <HeroOverlay
 *   image={{ src: "/hero.png", alt: "" }}
 *   heading="Welcome"
 *   subheading="Build faster with our blocks"
 *   cta1={{ label: "Get Started", href: "#getstarted" }}
 * />
 */
export declare function HeroOverlay({ id, className, imageSrc, imageAlt, imageObjectFit, imageObjectPosition, image, heading, subheading, overlayRGBA, overlayDarkRGBA, ctaBtn1Label, ctaBtn1Href, ctaBtn2Label, ctaBtn2Href, container, section, imageContainer, overlay, content, textContainer, headingStyle, subheadingStyle, ctaContainer, cta1, cta2, ariaLabel, enableMotion, }: HeroOverlayProps): React.JSX.Element;
//# sourceMappingURL=HeroOverlay.d.ts.map