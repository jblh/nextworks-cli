import React from "react";
/**
 * Represents individual pricing plan data.
 * @public
 */
export interface PricingData {
    /** Title of the plan (e.g., "Pro") */
    pricingPlanHeaderText?: string;
    /** Display price (e.g., "$19.99") */
    pricingPlanPrice?: string;
    /** Feature list bullets */
    pricingPlanFeatures?: string[];
    /** CTA button label */
    pricingPlanCTALabel?: string;
    /** CTA button href */
    pricingPlanCTAHref?: string;
    /** Whether this plan should be highlighted */
    isPopular?: boolean;
}
/**
 * Props for the Pricing section component.
 *
 * @remarks
 * - Styling: slot-style className overrides are merged after defaults via cn().
 * - Motion: enableMotion toggles entrance animations and hover transitions.
 * - Accessibility: uses a semantic <section> with an aria-label.
 */
interface PricingProps {
    /** Optional id on root. @defaultValue "pricing" */
    id?: string;
    /** Merge-in class for root */
    className?: string;
    /** Heading text displayed at the top of the pricing section. @defaultValue "Choose Your Plan" */
    pricingHeadingText?: string;
    /** Array of individual pricing plans to display. @defaultValue defaultPricingData */
    pricingPlans?: PricingData[];
    /** When false, disables entrance animations and hover transitions */
    enableMotion?: boolean;
    /** Styling configuration objects */
    section?: {
        className?: string;
    };
    container?: {
        className?: string;
    };
    heading?: {
        className?: string;
    };
    grid?: {
        className?: string;
    };
    card?: {
        className?: string;
    };
    header?: {
        className?: string;
    };
    title?: {
        className?: string;
    };
    price?: {
        className?: string;
    };
    features?: {
        className?: string;
    };
    featureItem?: {
        className?: string;
    };
    cta?: {
        unstyled?: boolean;
        style?: React.CSSProperties;
        variant?: "default" | "destructive" | "outline" | "secondary" | "ghost" | "link";
        size?: "default" | "sm" | "lg" | "icon";
        className?: string;
    };
    popularBadge?: {
        className?: string;
    };
    /** ARIA label for the pricing section */
    ariaLabel?: string;
}
/**
 * Responsive pricing grid using PricingCard with optional motion.
 *
 * @remarks
 * - Styling: exposes slot-style overrides (card, header, title, price, etc.).
 * - Motion: enableMotion controls entrance animations and hover transitions.
 * - Accessibility: semantic <section> with aria-label.
 *
 * @example
 * <Pricing pricingPlans={[{ pricingPlanHeaderText: 'Pro', pricingPlanPrice: '$19' }]} />
 */
export declare function Pricing({ id, className, pricingPlans, pricingHeadingText, enableMotion, section, container, heading, grid, card, header, title, price, features, featureItem, cta, popularBadge, ariaLabel, }: PricingProps): React.JSX.Element;
export {};
//# sourceMappingURL=Pricing.d.ts.map