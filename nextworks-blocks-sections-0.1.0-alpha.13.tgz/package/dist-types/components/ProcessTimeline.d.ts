import React from "react";
/**
 * Interface for individual process steps.
 * @public
 */
export interface ProcessStep {
    /** Ordinal step number starting at 1 */
    stepNumber: number;
    /** Short title for the step */
    title: string;
    /** Description of what happens in this step */
    description: string;
    /** Optional icon or emoji to visually represent the step */
    icon?: string;
}
/**
 * Props for configuring the ProcessTimeline component (slot-style + cn).
 *
 * @remarks
 * - Styling: exposes slot-style className overrides; consumer classes merge
 *   after defaults via cn().
 * - Layout: renders a horizontal timeline on desktop and vertical on mobile.
 * - Accessibility: semantic <section> with aria-label.
 */
export interface ProcessTimelineProps {
    /** Optional id on root */
    id?: string;
    /** Root className merged into section slot */
    className?: string;
    /** Array of steps to render. @defaultValue a 4-step discovery-to-launch flow */
    steps?: ProcessStep[];
    /** Section heading text. @defaultValue "Our Process" */
    heading?: string;
    /** Optional subheading text */
    subheading?: string;
    /** Styling configuration objects */
    section?: {
        className?: string;
    };
    container?: {
        className?: string;
    };
    header?: {
        className?: string;
    };
    headingStyle?: {
        className?: string;
    };
    subheadingStyle?: {
        className?: string;
    };
    timelineContainer?: {
        className?: string;
    };
    desktopTimeline?: {
        className?: string;
    };
    connectingLine?: {
        className?: string;
    };
    stepContainer?: {
        className?: string;
    };
    stepCircle?: {
        className?: string;
    };
    stepNumber?: {
        className?: string;
    };
    stepIcon?: {
        className?: string;
    };
    stepContent?: {
        className?: string;
    };
    stepTitle?: {
        className?: string;
    };
    stepDescription?: {
        className?: string;
    };
    mobileTimeline?: {
        className?: string;
    };
    mobileStep?: {
        className?: string;
    };
    mobileVerticalLine?: {
        className?: string;
    };
    mobileStepCircle?: {
        className?: string;
    };
    mobileStepContent?: {
        className?: string;
    };
    mobileStepIcon?: {
        className?: string;
    };
    mobileStepTitle?: {
        className?: string;
    };
    mobileStepDescription?: {
        className?: string;
    };
    /** ARIA label for the process timeline section */
    ariaLabel?: string;
}
/**
 * Responsive timeline showing a multi-step process for your workflow.
 *
 * @remarks
 * - Renders horizontally on desktop and vertically on mobile.
 * - Slot-style className overrides are merged after defaults via cn().
 * - Uses a semantic <section> and supports aria-label.
 *
 * @example
 * <ProcessTimeline steps={[{ stepNumber: 1, title: 'Plan', description: '...' }]} />
 */
export declare function ProcessTimeline({ id, className, steps, heading, subheading, section, container, header, headingStyle, subheadingStyle, timelineContainer, desktopTimeline, connectingLine, stepContainer, stepCircle, stepNumber, stepIcon, stepContent, stepTitle, stepDescription, mobileTimeline, mobileStep, mobileVerticalLine, mobileStepCircle, mobileStepContent, mobileStepIcon, mobileStepTitle, mobileStepDescription, ariaLabel, }: ProcessTimelineProps): React.JSX.Element;
//# sourceMappingURL=ProcessTimeline.d.ts.map