import React from "react";
/**
 * Props for the CTA section component.
 *
 * @remarks
 * Uses a slot-style API for Tailwind className overrides. Each slot's
 * className is merged with component defaults via cn().
 *
 * Prefer customizing spacing via headingText.className and other slot
 * classNames rather than legacy spacing props.
 *
 * @public
 */
interface CTAProps {
    /**
     * Optional id for the section.
     * @defaultValue "cta"
     */
    id?: string;
    /** Optional top-level class to override the section root */
    className?: string;
    /** Styling configuration objects (slot-style pattern like Navbar) */
    section?: {
        className?: string;
    };
    container?: {
        className?: string;
    };
    contentWrapper?: {
        className?: string;
    };
    headingText?: {
        text?: string;
        className?: string;
    };
    subheadingText?: {
        text?: string;
        className?: string;
    };
    descriptionText?: {
        text?: string;
        className?: string;
    };
    actionsWrapper?: {
        className?: string;
    };
    /**
     * Primary CTA config or null to hide it (mirrors Navbar ctaButton pattern)
     * Example: { label: "Get Started", href: "#contact" }
     */
    ctaButton?: {
        label: string;
        href: string;
    } | null;
    /** Primary CTA button styles */
    ctaButtonStyle?: {
        unstyled?: boolean;
        style?: React.CSSProperties;
        variant?: "default" | "destructive" | "outline" | "secondary" | "ghost" | "link";
        size?: "default" | "sm" | "lg" | "icon";
        className?: string;
    };
    /** Optional wrapper slot for the primary CTA */
    ctaButtonWrapper?: {
        className?: string;
    };
    /** Optional secondary action */
    secondaryButton?: {
        label: string;
        href: string;
    } | null;
    /** Secondary CTA button styles */
    secondaryButtonStyle?: {
        unstyled?: boolean;
        style?: React.CSSProperties;
        variant?: "default" | "destructive" | "outline" | "secondary" | "ghost" | "link";
        size?: "default" | "sm" | "lg" | "icon";
        className?: string;
    };
    /** Optional wrapper slot for the secondary CTA */
    secondaryButtonWrapper?: {
        className?: string;
    };
    /**
     * Legacy spacing hook applied to the heading.
     * @deprecated Prefer margin utilities via headingText.className
     */
    spacing?: {
        topMargin?: string;
    };
    /** Accessibility */
    ariaLabel?: string;
    role?: string;
}
/**
 * Call-to-Action section with a heading, optional subheading/description,
 * and up to two actions (primary and secondary).
 *
 * @remarks
 * - Styling: exposes slot-style className overrides (section, container,
 *   contentWrapper, headingText, subheadingText, descriptionText, actionsWrapper,
 *   ctaButtonStyle, secondaryButtonStyle). Consumer classes are merged after
 *   defaults via cn().
 * - Accessibility: rendered as a semantic <section> with aria-label. The role
 *   defaults to "region" but can be customized with the role prop.
 * - Motion: subtle hover lift effects on buttons are included by default.
 *
 * @example
 * <CTA
 *   headingText={{ text: "Join The Launch Today!" }}
 *   descriptionText={{ text: "Start your free trial in minutes." }}
 *   ctaButton={{ label: "Sign Up", href: "#contact" }}
 *   secondaryButton={{ label: "Learn More", href: "#features" }}
 * />
 */
export declare function CTA({ id, className, section, container, contentWrapper, headingText, subheadingText, descriptionText, actionsWrapper, ctaButton, ctaButtonStyle, ctaButtonWrapper, secondaryButton, secondaryButtonStyle, secondaryButtonWrapper, spacing, ariaLabel, role, }: CTAProps): React.JSX.Element;
export {};
//# sourceMappingURL=CTA.d.ts.map