import React from "react";
/**
 * Data structure representing a single service card.
 */
export interface ServiceCardData {
    icon: string;
    title: string;
    description: string;
}
/**
 * Props to configure the ServicesGrid component (upgraded slots + cn).
 */
export interface ServicesGridProps {
    /** Optional id on root */
    id?: string;
    /** Root className merged into section slot */
    className?: string;
    sectionHeading?: string;
    servicesData?: ServiceCardData[];
    /** When false, disables entrance animations and hover transitions */
    enableMotion?: boolean;
    /** Styling configuration objects */
    section?: {
        className?: string;
    };
    container?: {
        className?: string;
    };
    heading?: {
        className?: string;
    };
    grid?: {
        className?: string;
    };
    card?: {
        className?: string;
    };
    cardContent?: {
        className?: string;
    };
    icon?: {
        className?: string;
    };
    title?: {
        className?: string;
    };
    description?: {
        className?: string;
    };
    /** ARIA label for the services section */
    ariaLabel?: string;
}
/**
 * Responsive services grid with subtle motion and slot-style overrides.
 *
 * @remarks
 * - Motion can be disabled globally with enableMotion.
 * - Each card uses simple emoji icons by default; replace with real icons if preferred.
 *
 * @example
 * <ServicesGrid servicesData={[{ icon: '⚙️', title: 'Automation', description: '...' }]} />
 */
export declare function ServicesGrid({ id, className, sectionHeading, servicesData, enableMotion, section, container, heading, grid, card, cardContent, icon, title, description, ariaLabel, }: ServicesGridProps): React.JSX.Element;
//# sourceMappingURL=ServicesGrid.d.ts.map